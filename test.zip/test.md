Test notes!
===========
Split 1
-------
### These notes have an image. The img src is:
`https://raw.githubusercontent.com/SushiKishi/SushiRepo/refs/heads/main/faqmiko.gif`
![](https://raw.githubusercontent.com/SushiKishi/SushiRepo/refs/heads/main/faqmiko.gif)  
### If you're viewing via browser (i.e. SplitGuide\_Server.exe), you can see the above image. If you're viewing via the SplitGuide.exe viewer, the image will not load.
<!split>

Test notes!
===========
Split 2
-------
### These notes have an image. The img src is:
`faqmiko.gif`
![](faqmiko.gif)  
### If you're viewing via browser (i.e. SplitGuide\_Server.exe), you can see the above image. If you're viewing via the SplitGuide.exe viewer, the image will not load.
<!split>

